function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Sh2ZHbszNa":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

